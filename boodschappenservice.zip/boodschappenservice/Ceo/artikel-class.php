<?php
class Artikel
{
    public $artId;
    public $artOmschrijving;
    public $artInkoop;
    public $artVerkoop;
    public $artVoorraad;
    public $artMinVoorraad;
    public $artMaxVoorraad;
    public $artLocatie;
    public $levId;

    // Constructor to initialize the article object
    public function __construct($artId, $artOmschrijving, $artInkoop, $artVerkoop, $artVoorraad, $artMinVoorraad, $artMaxVoorraad, $artLocatie, $levId)
    {
        $this->artId = NULL;
        $this->artOmschrijving = $artOmschrijving;
        $this->artInkoop = $artInkoop;
        $this->artVerkoop = $artVerkoop;
        $this->artVoorraad = $artVoorraad;
        $this->artMinVoorraad = $artMinVoorraad;
        $this->artMaxVoorraad = $artMaxVoorraad;
        $this->artLocatie = $artLocatie;
        $this->levId = $levId;
    }

    

    // Getter methods
    public function getartId()
    {
        return $this->artId;
    }
    public function getartOmschrijving()
    {
        return $this->artOmschrijving;
    }
    public function getartInkoop()
    {
        return $this->artInkoop;
    }
    public function getartVerkoop()
    {
        return $this->artVerkoop;
    }
    public function getartVoorraad()
    {
        return $this->artVoorraad;
    }
    public function getartMinVoorraad()
    {
        return $this->artMinVoorraad;
    }
    public function getartMaxVoorraad()
    {
        return $this->artMaxVoorraad;
    }
    public function getartLocatie()
    {
        return $this->artLocatie;
    }
    public function getlevId()
    {
        return $this->levId;
    }
}