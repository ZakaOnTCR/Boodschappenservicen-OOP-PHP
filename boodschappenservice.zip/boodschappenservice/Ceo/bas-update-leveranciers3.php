<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

    <?php

    require_once "gar-connect.php";
    require_once "leveranciers-class.php";

    // Get values from the form
    $levid = $_POST['levid'];
    $levnaam = $_POST['levnaam'];
    $levcontact = $_POST['levcontact'];
    $levEmail = $_POST['levEmail'];
    $levAdres = $_POST['levAdres'];
    $levPostcode = $_POST['levPostcode'];
    $levWoonplaats = $_POST['levWoonplaats'];

    // Create a new leverancier object with the new values
    $leverancier = new Leverancier($levid, $levnaam, $levcontact, $levEmail, $levAdres, $levPostcode, $levWoonplaats);

    // Update the customer record in the database
    $sql = $conn->prepare("UPDATE leveranciers SET levnaam=:levnaam, levcontact=:levcontact, levEmail=:levEmail, levAdres=:levAdres, levPostcode=:levPostcode WHERE levid=:levid");
    $sql->execute([
        "levid" => $levid,
        "levnaam" => $levnaam,
        "levcontact" => $levcontact,
        "levEmail" => $levEmail,
        "levAdres" => $levAdres,
        "levPostcode" => $levPostcode,
    ]);

    echo "leverancier succesvol geüpdatet!";

    ?>


</div>