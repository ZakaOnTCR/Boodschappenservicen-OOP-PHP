<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

    <?php
    require_once('verkooporders-class.php'); // Inclusief de Artikel-klasse
    require_once('gar-connect.php'); // Inclusief de database-configuratie
    



    // Maak een nieuw Verkooporder-object aan
    $verkooporder = new verkooporder();

    // Roep de delete methode aan om de Verkooporder uit de database te verwijderen
    $verkooporder->verkOrdId = $_POST['verkOrdId'];
    $verkooporder->delete();

    ?>


</div>