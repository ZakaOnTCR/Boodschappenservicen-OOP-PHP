<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>
<div class="container">
    <?php
    require_once "gar-connect.php";
    require_once "leveranciers-class.php";
    // Verbinding maken met de database (vervang de waarden met die van jouw database)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $levid = $_POST["levid"];

    // Zoek de leverancier in de database
    $stmt = $conn->prepare("SELECT * FROM leveranciers WHERE levid = :levid");
    $stmt->bindParam(":levid", $levid);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Toon de eigenschappen van de leverancier als deze gevonden is
    if ($result) {
        $leverancier = new leverancier($result["levid"], $result["levnaam"], $result["levcontact"], $result["levEmail"], $result["levAdres"], $result["levPostcode"], $result["levWoonplaats"]);
        echo "<table class='table table-dark table-hover'>";
        echo "<tr>";
        echo "<td>" . "levid: " . $leverancier->levid . "<br>" . "</td>";
        echo "<td>" . "levnaam: " . $leverancier->levnaam . "</td>" . "<br>";
        echo "<td>" . "levcontact: " . $leverancier->levcontact . "</td>" . "<br>";
        echo "<td>" . "levEmail: " . $leverancier->levEmail . "</td>" . "<br>";
        echo "<td>" . "levAdres: " . $leverancier->levAdres . "</td>" . "<br>";
        echo "<td>" . "levPostcode: " . $leverancier->levPostcode . "</td>" . "<br>";
        echo "<td>" . "levWoonplaats: " . $leverancier->levWoonplaats . "</td>" . "<br>";
        echo "</tr>";
        echo "</table>";
    } else {
        echo "leverancier niet gevonden";
    }
}

$conn = null;
?>
</div>
</body>
</html>