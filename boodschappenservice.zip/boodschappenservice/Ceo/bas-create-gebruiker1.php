<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>
<div class="contact-form">
    <h1 class="create-klant">garage create gebruiker 1</h1>
    <div class="Lijn"></div>
    <p class="create-klant"> Dit formulier wordt gebruikt om gebruikergegevens in te voeren </p>
    <form class="form" action="bas-create-gebruiker2.php" method="post">
        <label for="gebruikernaam">naam</label>
        <input type="text" name="gebruikernaam"><br>

        <label for="gebruikerleeftijd">gebruikerleeftijd</label>
        <input type="date" name="gebruikerleeftijd"><br>

        <label for="gebruikeremail">gebruikeremail</label>
        <input type="text" name="gebruikeremail"><br>

        <label for="gebruikerwachtwoordvak">gebruikerwachtwoord</label>
        <input type="text" name="gebruikerwachtwoord"><br>

        <input type="checkbox" id="vehicle1" name="gebruikerrol" value="Magazijnmeester">
        <label for="rol1">Magazijnmeester</label><br>
        <input type="checkbox" id="vehicle2" name="gebruikerrol" value="Verkoper">
        <label for="rol2"> Verkoper</label><br>
        <input type="checkbox" id="vehicle3" name="gebruikerrol" value="Magazijnmedewerker">
        <label for="rol3">Magazijnmedewerker</label><br><br>
        <input type="checkbox" id="vehicle4" name="gebruikerrol" value="Bezorger">
        <label for="rol3">Bezorger</label><br><br>
        <input type="checkbox" id="vehicle5" name="gebruikerrol" value="Inkoper">
        <label for="rol3">Inkoper</label><br><br>
        <input type="checkbox" id="vehicle5" name="gebruikerrol" value="Ceo">
        <label for="rol3">Ceo</label><br><br>
        <br>


        <input type="submit">
    </form>
</div>
</body>
</html>
