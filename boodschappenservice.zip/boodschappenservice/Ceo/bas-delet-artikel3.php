<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

    <?php
    require_once('artikel-class.php'); // Inclusief de Artikel-klasse
    require_once('gar-connect.php'); // Inclusief de database-configuratie
    
    $artikel = new Artikel(null, null, null, null, null, null, null, null, null);

    if (isset($_POST['artId'])) {
        $artikel->artId = $_POST['artId'];

        // DELETE query uitvoeren
        $query = "DELETE FROM artikelen WHERE artId = :artId";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':artId', $artikel->artId);
        $stmt->execute();

        echo "Artikel met ID " . $artikel->artId . " is succesvol verwijderd.";
    } else {
        echo "Geen artikel ID opgegeven.";
    }
    ?>

</div>