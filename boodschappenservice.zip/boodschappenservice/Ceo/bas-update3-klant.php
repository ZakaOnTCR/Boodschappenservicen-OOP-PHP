<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

    <?php

    require_once "gar-connect.php";
    require_once "klant-class.php";

    // Get values from the form
    $klantid = $_POST['klantid'];
    $klantnaam = $_POST['klantnaam'];
    $klantemail = $_POST['klantemail'];
    $klantadres = $_POST['klantadres'];
    $klantpostcode = $_POST['klantpostcode'];
    $klantwoonplaats = $_POST['klantwoonplaats'];

    // Create a new Klant object with the new values
    $klant = new Klant($klantid, $klantnaam, $klantemail, $klantadres, $klantpostcode, $klantwoonplaats);

    // Update the customer record in the database
    $sql = $conn->prepare("UPDATE klanten SET klantnaam=:klantnaam, klantemail=:klantemail, klantadres=:klantadres, klantpostcode=:klantpostcode, klantwoonplaats=:klantwoonplaats WHERE klantid=:klantid");
    $sql->execute([
        "klantid" => $klantid,
        "klantnaam" => $klantnaam,
        "klantemail" => $klantemail,
        "klantadres" => $klantadres,
        "klantpostcode" => $klantpostcode,
        "klantwoonplaats" => $klantwoonplaats,
    ]);

    echo "Klant succesvol geüpdatet!";

    ?>


</div>