<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>

    <div class="container">
        <table class="table table-dark table-hover">
            <tr>
                <th>verkOrdId</th>
                <th>artId</th>
                <th>verkOrdDatum</th>
                <th>verkOrdBestAantal</th>
                <th>verkOrdStatus</th>
            </tr>

            <?php
            // artikelkenteken uit het formulier halen
            $verkOrdId = $_POST["verkOrdId"];

            require_once "gar-connect.php";
            global $conn;
            $verkooporders = $conn->prepare("
select verkOrdId, klantid, artId, verkOrdDatum, verkOrdBestAantal, verkOrdStatus
from verkooporders
where verkOrdId = :verkOrdId
");
            $verkooporders->execute(["verkOrdId" => $verkOrdId]);


            // artikelgegevens laten zien
            

            foreach ($verkooporders as $verkooporder) {
                echo "<tr>";
                echo "<form class='form' action='bas-delet3-verkooporder.php' method='post'>";
                echo "<td>" . $verkooporder["verkOrdId"] . "</td>";
                echo "<td>" . $verkooporder["artId"] . "</td>";
                echo "<td>" . $verkooporder["verkOrdDatum"] . "</td>";
                echo "<td>" . $verkooporder["verkOrdBestAantal"] . "</td>";
                echo "<td>" . $verkooporder["verkOrdStatus"] . "</td>";
                echo "</tr>";
                echo "</form>";
            }
            echo "</table><br />";
            ?>
            <form action="bas-delete-verkooporders3.php" method="post">
                <h4>Wil je de verkooporder verwijderen?</h4>
                <input type='hidden' name='verkOrdId' value='<?php echo $verkOrdId; ?>'>
                <input type='submit' value='Verwijderen'>
            </form>
    </div>

</body>

</html>