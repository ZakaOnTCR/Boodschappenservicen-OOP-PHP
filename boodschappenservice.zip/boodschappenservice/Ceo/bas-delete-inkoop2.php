<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>

    <div class="container">
        <table class="table table-dark table-hover">
            <tr>
                <th>inkOrdId</th>
                <th>levId</th>
                <th>artId</th>
                <th>inkOrdDatum</th>
                <th>inkOrdBestAantal</th>
                <th>inkOrdStatus</th>
            </tr>

            <?php
            // artikelkenteken uit het formulier halen
            $inkOrdId = $_POST["inkOrdId"];

            require_once "gar-connect.php";
            global $conn;
            $inkooporders = $conn->prepare("
select inkOrdId, levId, artId, inkOrdDatum, inkOrdBestAantal, inkOrdStatus
from inkooporders
where inkOrdId = :inkOrdId
");
            $inkooporders->execute(["inkOrdId" => $inkOrdId]);

            // artikelgegevens laten zien
            

            foreach ($inkooporders as $inkooporder) {
                echo "<tr>";
                echo "<form class='form' action='bas-delet3-inkooporder.php' method='post'>";
                echo "<td>" . $inkooporder["inkOrdId"] . "</td>";
                echo "<td>" . $inkooporder["levId"] . "</td>";
                echo "<td>" . $inkooporder["artId"] . "</td>";
                echo "<td>" . $inkooporder["inkOrdDatum"] . "</td>";
                echo "<td>" . $inkooporder["inkOrdBestAantal"] . "</td>";
                echo "<td>" . $inkooporder["inkOrdStatus"] . "</td>";
                echo "</tr>";
                echo "</form>";
            }
            echo "</table><br />";
            ?>
            <form action="bas-delete-inkoop3.php" method="post">
                <h4>Wil je de inkooporder verwijderen?</h4>
                <input type='hidden' name='inkOrdId' value='<?php echo $inkOrdId; ?>'>
                <input type='submit' value='Verwijderen'>
            </form>
    </div>

</body>

</html>