<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create klanten-2</title>
</head>

<body>
    <?php require_once "navbar.php"; ?>
    <div class="uitgevoerd">
        <?php
        require_once "klant-class.php";

        function addCustomer()
        {
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $nieuwe_klant = new Klant(NULL, $_POST['klantnaamvak'], $_POST['klantemailvak'], $_POST['klantadresvak'], $_POST['klantpostcodevak'], $_POST['klantwoonplaatsvak']);
                // Maak een SQL-query aan om de nieuwe klant toe te voegen
                $klantnaam = $nieuwe_klant->getklantnaam();
                $klantemail = $nieuwe_klant->getklantemail();
                $klantadres = $nieuwe_klant->getklantadres();
                $klantpostcode = $nieuwe_klant->getklantpostcode();
                $klantwoonplaats = $nieuwe_klant->getklantwoonplaats();

                require_once "gar-connect.php";

                $stmt = $conn->prepare("INSERT INTO klanten (klantnaam, klantemail, klantadres, klantpostcode, klantwoonplaats) VALUES (:klantnaam, :klantemail, :klantadres, :klantpostcode, :klantwoonplaats)");

                $stmt->bindParam(':klantnaam', $klantnaam);
                $stmt->bindParam(':klantemail', $klantemail);
                $stmt->bindParam(':klantadres', $klantadres);
                $stmt->bindParam(':klantpostcode', $klantpostcode);
                $stmt->bindParam(':klantwoonplaats', $klantwoonplaats);

                // Voer de query uit en check het resultaat
                if ($stmt->execute()) {
                    echo "<p>Klant toegevoegd!</p>";
                } else {
                    echo "<p>Er is iets misgegaan. De klant is niet toegevoegd.</p>";
                }
            }
        }

        addCustomer();

        ?>
    </div>

</body>

</html>