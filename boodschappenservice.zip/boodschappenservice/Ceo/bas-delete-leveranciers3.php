<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

    <?php
    require_once('gar-connect.php'); // Inclusief de Artikel-klasse
    require_once('leveranciers-class.php'); // Inclusief de database-configuratie
    
    $leverancier = new Leverancier(null, null, null, null, null, null, null);

    if (isset($_POST['levid'])) {
        $leverancier->levid = $_POST['levid'];

        // DELETE query uitvoeren
        $query = "DELETE FROM Leveranciers WHERE levid = :levid";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':levid', $leverancier->levid);
        $stmt->execute();

        echo "leverancier met ID " . $leverancier->levid . " is succesvol verwijderd.";
    } else {
        echo "Geen leverancier ID opgegeven.";
    }
    ?>

</div>