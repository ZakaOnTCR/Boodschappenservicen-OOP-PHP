<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>
    <?php

    require_once "gar-connect.php";
    require_once "leveranciers-class.php";
    
    if (isset($_POST['levid'])) {
        // Haal het leverancier-ID op uit het formulier
        $levid = $_POST['levid'];
    
        // Maak een nieuw leverancier-object met het leverancier-ID
        $leverancier = new Leverancier($levid, "", "", "", "", "", "");
    
        // Gebruik de getter-methoden om de huidige eigenschappen van de leverancier op te halen
        $levnaam = $leverancier->getlevnaam();
        $levcontact = $leverancier->getlevcontact();
        $levEmail = $leverancier->getlevEmail();
        $levAdres = $leverancier->getlevAdres();
        $levPostcode = $leverancier->getlevPostcode();
        $levWoonplaats = $leverancier->getlevWoonplaats();
    
        global $conn;
        $leveranciers = $conn->prepare("
    select levid, levnaam, levcontact, levEmail, levAdres, levPostcode, levWoonplaats 
    from leveranciers
    where levid = :levid
    ");
        $leveranciers->execute(["levid" => $levid]);
    
        // leveranciergegevens in een nieuw formulier laten zien
        echo " <form class='form' action='bas-update-leveranciers3.php' method='post'>";
        foreach ($leveranciers as $leverancier) {
            // levid mag niet gewijzigd worden
            echo "levid: <input type='text' ";
            echo "name='levid'";
            echo "value= '" . $leverancier["levid"] . " '";
            echo " readonly> <br />";
    
            echo "levnaam: <input type='text' ";
            echo "name='levnaam'";
            echo "value= '" . $leverancier["levnaam"] . "' ";
            echo " > <br />";
    
            echo "levcontact: <input type='text' ";
            echo "name='levcontact'";
            echo "value= '" . $leverancier["levcontact"] . "' ";
            echo " > <br />";
    
            echo "levEmail: <input type='text'";
            echo "name='levEmail'";
            echo "value= '" . $leverancier["levEmail"] . "' ";
            echo " > <br />";
    
            echo "levAdres: <input type='text' ";
            echo "name='levAdres'";
            echo "value= '" . $leverancier["levAdres"] . "' ";
            echo " > <br />";
    
            echo "levPostcode: <input type='text' ";
            echo "name='levPostcode'";
            echo "value= '" . $leverancier["levPostcode"] . "' ";
            echo " > <br />";

            echo "levWoonplaats: <input type='text' ";
            echo "name='levWoonplaats'";
            echo "value= '" . $leverancier["levWoonplaats"] . "' ";
            echo " > <br />";
        }
        echo "<input type='submit' name='submit_button' value='Verzenden'>";
        echo "</form>";
        echo "</div>";
    
        exit();
    }
    ?>
    