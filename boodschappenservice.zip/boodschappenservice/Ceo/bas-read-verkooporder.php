<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>


    <div class="container">
        <div class="tbl-header">
            <table cellpadding="0" cellspacing="0" border="0">
                <thead>
                    <tr>
                        <th>verkOrdId</th>
                        <th>klantid</th>
                        <th>artId</th>
                        <th>verkOrdDatum</th>
                        <th>verkOrdBestAantal</th>
                        <th>verkOrdStatus</th>
                    </tr>
                </thead>
        </div>


        <?php
        require_once "gar-connect.php";

        require "verkooporders-class.php";

        // Step 1: Create a SQL query to retrieve all the data from the "Verkooporders" table
        $verkooporder = new Verkooporder(NULL, NULL, NULL, NULL, NULL, NULL);
        // Call the delete method to delete the Verkooporder from the database
        $verkooporder->read();

        ?>
        </table>
    </div>

</body>

</html>