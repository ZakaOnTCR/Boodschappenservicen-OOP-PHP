<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>

    <div class="container">
        <table class="table table-dark table-hover">
            <tr>
                <th>levid</th>
                <th>levnaam</th>
                <th>levcontact</th>
                <th>levEmail</th>
                <th>levAdres</th>
                <th>levPostcode</th>
                <th>levWoonplaats</th>
            </tr>

            <?php
            // artikelkenteken uit het formulier halen
            $levid = $_POST["levid"];

            require_once "gar-connect.php";
            global $conn;
            $leveranciers = $conn->prepare("
select levid, levnaam, levcontact, levEmail, levAdres, levPostcode, levWoonplaats
from leveranciers
where levid = :levid
");
            $leveranciers->execute(["levid" => $levid]);

            // artikelgegevens laten zien


            foreach ($leveranciers as $leverancier) {
                echo "<tr>";
                echo "<form class='form' action='bas-delete-leveranciers3.php' method='post'>";
                echo "<td>" . $leverancier["levid"] . "</td>";
                echo "<td>" . $leverancier["levnaam"] . "</td>";
                echo "<td>" . $leverancier["levcontact"] . "</td>";
                echo "<td>" . $leverancier["levEmail"] . "</td>";
                echo "<td>" . $leverancier["levAdres"] . "</td>";
                echo "<td>" . $leverancier["levPostcode"] . "</td>";
                echo "<td>" . $leverancier["levWoonplaats"] . "</td>";
                echo "</tr>";
                echo "</form>";
            }
            echo "</table><br />";
            ?>
            <form action="bas-delete-leveranciers3.php" method="post">
                <h4>Wil je de leverancier verwijderen?</h4>
                <input type='hidden' name='levid' value='<?php echo $levid; ?>'>
                <input type='submit' value='Verwijderen'>
            </form>
    </div>

</body>

</html>