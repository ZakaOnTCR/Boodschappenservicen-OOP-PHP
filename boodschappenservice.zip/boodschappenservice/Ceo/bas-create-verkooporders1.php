<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create artikelen</title>
</head>
<body>
<?php require_once "navbar.php" ?>
<form class="form" method="post" action="bas-create-verkooporders2.php">
  <label for="klantid">klantid:</label>
  <input type="text" id="klantid" name="klantid"><br>

  <label for="artId">artId :</label>
  <input id="artId" name="artId"></input><br>

  <label for="verkOrdDatum">verkOrdDatum:</label>
  <input type="text" id="verkOrdDatum" name="verkOrdDatum"><br>

  <label for="verkOrdBestAantal">verkOrdBestAantal:</label>
  <input type="text" id="verkOrdBestAantal" name="verkOrdBestAantal"><br>

  <label for="verkOrdStatus">verkOrdStatus:</label>
  <input type="text" id="verkOrdStatus" name="verkOrdStatus"><br>


  <input type="submit" value="Toevoegen">
</form>

</body>
</html>