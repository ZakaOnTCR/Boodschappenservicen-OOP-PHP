<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create klanten</title>
</head>
<body>
<?php require_once "navbar.php" ?>
<form class="form" method="post" action="bas-create-klant2.php">
  <label for="klantnaam">Klantnaam:</label>
  <input type="text" id="klantnaam" name="klantnaamvak"><br>
<label for="klantemail">Klantemail:</label>
<input id="klantemail" name="klantemailvak"></input><br>

<label for="klantadres">Klantadres:</label>
<input type="text" id="klantadres" name="klantadresvak"><br>

<label for="klantpostcode">Klantpostcode:</label>
<input type="text" id="klantpostcode" name="klantpostcodevak"><br>

<label for="klantwoonplaats">Klantwoonplaats:</label>
<input type="text" id="klantwoonplaats" name="klantwoonplaatsvak"><br>

  <input type="submit" value="Toevoegen">
</form>
</body>
</html>