<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create artikelen</title>
</head>
<body>
<?php require_once "navbar.php" ?>
<form class="form" method="post" action="bas-create-artikel2.php">
  <label for="artOmschrijving">artOmschrijving:</label>
  <input type="text" id="artOmschrijving" name="artOmschrijvingvak"><br>

  <label for="artInkoop">artInkoop:</label>
  <input id="artInkoop" name="artInkoopvak"></input><br>

  <label for="artVerkoop">artVerkoop:</label>
  <input type="text" id="artVerkoop" name="artVerkoopvak"><br>

  <label for="artVoorraad">artVoorraad:</label>
  <input type="text" id="artVoorraad" name="artVoorraadvak"><br>

  <label for="artMinVoorraad">artMinVoorraad:</label>
  <input type="text" id="artMinVoorraad" name="artMinVoorraadvak"><br>

  <label for="artMaxVoorraad">artMaxVoorraad:</label>
  <input type="text" id="artMaxVoorraad" name="artMaxVoorraadvak"><br>

  <label for="artLocatie">artLocatie:</label>
  <input type="text" id="artLocatie" name="artLocatievak"><br>

  <label for="levId">levId:</label>
  <input type="text" id="levId" name="levIdvak"><br>


  <input type="submit" value="Toevoegen">
</form>

</body>
</html>