<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create klanten</title>
</head>
<body>
<?php require_once "navbar.php" ?>
<form class="form" method="post" action="bas-create-leveranciers2.php">
  <label for="levnaam">levnaam:</label>
  <input type="text" id="levnaam" name="levnaam"><br>

<label for="levcontact">levcontact:</label>
<input id="levcontact" name="levcontact"></input><br>

<label for="levEmail">levEmail:</label>
<input type="text" id="levEmail" name="levEmail"><br>

<label for="levAdres">levAdres:</label>
<input type="text" id="levAdres" name="levAdres"><br>

<label for="levPostcode">levPostcode:</label>
<input type="text" id="levPostcode" name="levPostcode"><br>

<label for="levWoonplaats">levWoonplaats:</label>
<input type="text" id="levWoonplaats" name="levWoonplaats"><br>

  <input type="submit" value="Toevoegen">
</form>
</body>
</html>