<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create artikelen-2</title>
</head>

<body>
    <?php require_once "navbar.php"; ?>
    <div class="uitgevoerd">
        <?php


        require_once "artikel-class.php";


        function addProduct()
        {
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $nieuw_artikel = new Artikel(NULL, $_POST['artOmschrijvingvak'], $_POST['artInkoopvak'], $_POST['artVerkoopvak'], $_POST['artVoorraadvak'], $_POST['artMinVoorraadvak'], $_POST['artMaxVoorraadvak'], $_POST['artLocatievak'], $_POST['levIdvak']);

                // Maak een SQL-query aan om het nieuwe artikel toe te voegen
                $artOmschrijving = $nieuw_artikel->getartOmschrijving();
                $artInkoop = $nieuw_artikel->getartInkoop();
                $artVerkoop = $nieuw_artikel->getartVerkoop();
                $artVoorraad = $nieuw_artikel->getartVoorraad();
                $artMinVoorraad = $nieuw_artikel->getartMinVoorraad();
                $artMaxVoorraad = $nieuw_artikel->getartMaxVoorraad();
                $artLocatie = $nieuw_artikel->getartLocatie();
                $levId = $nieuw_artikel->getlevId();

                require_once "gar-connect.php";

                $stmt = $conn->prepare("INSERT INTO artikelen (artOmschrijving, artInkoop, artVerkoop, artVoorraad, artMinVoorraad, artMaxVoorraad, artLocatie, levId) VALUES (:artOmschrijving, :artInkoop, :artVerkoop, :artVoorraad, :artMinVoorraad, :artMaxVoorraad, :artLocatie, :levId)");

                $stmt->bindParam(':artOmschrijving', $artOmschrijving);
                $stmt->bindParam(':artInkoop', $artInkoop);
                $stmt->bindParam(':artVerkoop', $artVerkoop);
                $stmt->bindParam(':artVoorraad', $artVoorraad);
                $stmt->bindParam(':artMinVoorraad', $artMinVoorraad);
                $stmt->bindParam(':artMaxVoorraad', $artMaxVoorraad);
                $stmt->bindParam(':artLocatie', $artLocatie);
                $stmt->bindParam(':levId', $levId);

                // Voer de query uit en check het resultaat
                if ($stmt->execute()) {
                    echo "<p>Artikel toegevoegd!</p>";
                } else {
                    echo "<p>Er is iets misgegaan. Het artikel is niet toegevoegd.</p>";
                }
            }
        }
        addProduct();

        ?>
    </div>
</body>

</html>