<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<?php require_once "navbar.php" ?>

<body>
    <form class="form" method="POST" action="bas-delet-klant2.php">
        klant-ID: <input type="text" name="klantid" required>
        <input type="submit" value="Verwijderen">
    </form>
</body>
</html>