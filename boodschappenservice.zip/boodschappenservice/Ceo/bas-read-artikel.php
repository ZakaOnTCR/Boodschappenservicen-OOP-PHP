<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>


    <div class="container">
        <div class="tbl-header">
            <table cellpadding="0" cellspacing="0" border="0">
                <thead>
                    <tr>
                        <th>artId</th>
                        <th>artOmschrijving</th>
                        <th>artInkoop</th>
                        <th>artMinVoorraad</th>
                        <th>artVerkoop</th>
                        <th>artVoorraad</th>
                        <th>artMaxVoorraad</th>
                        <th>artLocatie</th>
                        <th>levId</th>
                    </tr>
                </thead>
                <?php
                require_once "gar-connect.php";

                require_once "artikel-class.php";

                // Step 1: Create a SQL query to retrieve all the data from the "artikelen" table
                $sql = "SELECT inkooporders.inkOrdId, inkooporders.levId, inkooporders.artId, inkooporders.inkOrdDatum, inkooporders.inkOrdBestAantal, inkooporders.inkOrdStatus, klanten.klantnaam
                FROM inkooporders
                INNER JOIN klanten ON inkooporders.inkOrdId = klanten.klantnaam";

                // Step 2: Prepare the SQL query using PDO
                $stmt = $conn->prepare($sql);

                // Step 3: Execute the SQL query
                $stmt->execute();

                // Step 4: Fetch the results and create Article objects for each row in the "artikelen" table
                $artikelen = array();
                while ($row = $stmt->fetch()) {
                    $artikel = new artikel($row["artId"], $row["artOmschrijving"], $row["artInkoop"], $row["artMinVoorraad"], $row["artVerkoop"], $row["artVoorraad"], $row["artMaxVoorraad"], $row["artLocatie"], $row["levId"]);
                    array_push($artikelen, $artikel);
                }

                // Step 5: Display the data in HTML table format
                

                foreach ($artikelen as $artikel) {
                    echo "<tr>";
                    echo "<td>" . $artikel->getartId() . "</td>";
                    echo "<td>" . $artikel->getartOmschrijving() . "</td>";
                    echo "<td>" . $artikel->getartInkoop() . "</td>";
                    echo "<td>" . $artikel->getartMinVoorraad() . "</td>";
                    echo "<td>" . $artikel->getartVerkoop() . "</td>";
                    echo "<td>" . $artikel->getartVoorraad() . "</td>";
                    echo "<td>" . $artikel->getartMaxVoorraad() . "</td>";
                    echo "<td>" . $artikel->getartLocatie() . "</td>";
                    echo "<td>" . $artikel->getlevId() . "</td>";
                    echo "<td>" . $artikel->getklantnaam() . "</td>";
                    echo "</tr>";
                }

                echo "</table>";

                ?>
        </div>

</body>

</html>