<?php
class inkooporder
{
    public $inkOrdId ;
    public $levId ;
    public $artId;
    public $inkOrdDatum;
    public $inkOrdBestAantal;
    public $inkOrdStatus;


    // Constructor to initialize the article object
    public function __construct($inkOrdId , $levId , $artId, $inkOrdDatum, $inkOrdBestAantal, $inkOrdStatus)
    {
        $this->inkOrdId  = NULL;
        $this->levId  = $levId ;
        $this->artId = $artId;
        $this->inkOrdDatum = $inkOrdDatum;
        $this->inkOrdBestAantal = $inkOrdBestAantal;
        $this->inkOrdStatus = $inkOrdStatus;
    }

    

    // Getter methods
    public function getinkOrdId ()
    {
        return $this->inkOrdId ;
    }
    public function getlevId ()
    {
        return $this->levId ;
    }
    public function getartId()
    {
        return $this->artId;
    }
    public function getinkOrdDatum()
    {
        return $this->inkOrdDatum;
    }
    public function getinkOrdBestAantal()
    {
        return $this->inkOrdBestAantal;
    }
    public function getinkOrdStatus()
    {
        return $this->inkOrdStatus;
    }
}