<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>
<div class="container">
    <?php
    require_once "gar-connect.php";
    require_once "klant-class.php";
    // Verbinding maken met de database (vervang de waarden met die van jouw database)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $klantid = $_POST["klantid"];

    // Zoek de klant in de database
    $stmt = $conn->prepare("SELECT * FROM Klanten WHERE klantid = :klantid");
    $stmt->bindParam(":klantid", $klantid);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Toon de eigenschappen van de klant als deze gevonden is
    if ($result) {
        $klant = new Klant($result["klantid"], $result["klantnaam"], $result["klantemail"], $result["klantadres"], $result["klantpostcode"], $result["klantwoonplaats"]);
        echo "<table class='table table-dark table-hover'>";
        echo "<tr>";
        echo "<td>" . "ID: " . $klant->klantid . "<br>" . "</td>";
        echo "<td>" . "Naam: " . $klant->klantnaam . "</td>" . "<br>";
        echo "<td>" . "Email: " . $klant->klantemail . "</td>" . "<br>";
        echo "<td>" . "Adres: " . $klant->klantadres . "</td>" . "<br>";
        echo "<td>" . "Postcode: " . $klant->klantpostcode . "</td>" . "<br>";
        echo "<td>" . "Woonplaats: " . $klant->klantwoonplaats . "</td>" . "<br>";
        echo "</tr>";
        echo "</table>";
    } else {
        echo "Klant niet gevonden";
    }
}

$conn = null;
?>
</div>
</body>
</html>