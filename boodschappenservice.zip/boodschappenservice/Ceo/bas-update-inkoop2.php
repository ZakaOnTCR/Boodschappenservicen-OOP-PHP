<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>
    <?php

    require_once "gar-connect.php";
    require_once "inkooporders-class.php";
    
    if (isset($_POST['inkOrdId'])) {
        // Haal het inkooporder-ID op uit het formulier
        $inkOrdId = $_POST['inkOrdId'];
    
        // Maak een nieuw inkooporder-object met het inkooporder-ID
        $inkooporder = new Inkooporder($inkOrdId, "", "", "", "", "");
    
        // Gebruik de getter-methoden om de huidige eigenschappen van de inkooporder op te halen
        $levId = $inkooporder->getlevId();
        $artId = $inkooporder->getartId();
        $inkOrdDatum = $inkooporder->getinkOrdDatum();
        $inkOrdBestAantal = $inkooporder->getinkOrdBestAantal();
        $inkOrdStatus = $inkooporder->getinkOrdStatus();
    
        global $conn;
        $inkooporders = $conn->prepare("
    select inkOrdId, levId, artId, inkOrdDatum, inkOrdBestAantal, inkOrdStatus
    from inkooporders
    where inkOrdId = :inkOrdId
    ");
        $inkooporders->execute(["inkOrdId" => $inkOrdId]);
    
        // inkoopordergegevens in een nieuw formulier laten zien
        echo " <form class='form' action='bas-update-inkoop3.php' method='post'>";
        foreach ($inkooporders as $inkooporder) {
            // inkOrdId mag niet gewijzigd worden
            echo "inkOrdId: <input type='text' ";
            echo "name='inkOrdId'";
            echo "value= '" . $inkooporder["inkOrdId"] . " '";
            echo " readonly> <br />";
    
            echo "levId: <input type='text' ";
            echo "name='levId'";
            echo "value= '" . $inkooporder["levId"] . "' ";
            echo " > <br />";
    
            echo "artId: <input type='text' ";
            echo "name='artId'";
            echo "value= '" . $inkooporder["artId"] . "' ";
            echo " > <br />";
    
            echo "inkOrdDatum: <input type='text'";
            echo "name='inkOrdDatum'";
            echo "value= '" . $inkooporder["inkOrdDatum"] . "' ";
            echo " > <br />";
    
            echo "inkOrdBestAantal: <input type='text' ";
            echo "name='inkOrdBestAantal'";
            echo "value= '" . $inkooporder["inkOrdBestAantal"] . "' ";
            echo " > <br />";
    
            echo "inkOrdStatus: <input type='text' ";
            echo "name='inkOrdStatus'";
            echo "value= '" . $inkooporder["inkOrdStatus"] . "' ";
            echo " > <br />";
        }
        echo "<input type='submit' name='submit_button' value='Verzenden'>";
        echo "</form>";
        echo "</div>";
    
        exit();
    }
    ?>
    