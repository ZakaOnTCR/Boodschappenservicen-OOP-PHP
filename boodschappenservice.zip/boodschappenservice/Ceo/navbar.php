<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../main.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <title>Document</title>

</head>

<header>
  <div class="navbar">
    <a href="#home">Home</a>
    <div class="subnav">
      <button class="subnavbtn">Artikelen <i class="fa fa-caret-down"></i></button>
      <div class="subnav-content">
        <a href="bas-create-artikel1.php">Artikel Toevoegen</a>
        <a href="bas-update-artikel1.php">Artikel Update</a>
        <a href="bas-read-artikel.php">Artikel Read</a>
        <a href="bas-delet-artikel1.php">Artikel Verwijderen</a>
        <a href="bas-search-artikel1.php">Artikel Zoeken</a>
      </div>
    </div>
    <div class="subnav">
      <button class="subnavbtn">Klanten <i class="fa fa-caret-down"></i></button>
      <div class="subnav-content">
        <a href="bas-create-klant1.php">Klant Toevoegen</a>
        <a href="bas-update1-klant.php">Klant Update</a>
        <a href="bas-read-klant.php">Klant Read</a>
        <a href="bas-delet-klant1.php">Klant Verwijderen</a>
        <a href="bas-search1-klant.php">Klant Zoeken</a>
      </div>
    </div>
    <div class="subnav">
      <button class="subnavbtn">Inkooporders <i class="fa fa-caret-down"></i></button>
      <div class="subnav-content">
        <a href="bas-create-inkoop1.php">Inkoop Toevoegen</a>
        <a href="bas-update-inkoop1.php">Inkoop Update</a>
        <a href="bas-read-inkooporder.php">Inkoop Read</a>
        <a href="bas-delete-inkoop1.php">Inkoop Verwijderen</a>
        <a href="bas-search-inkoop1.php">Inkoop Zoeken</a>
      </div>
    </div>
    <div class="subnav">
      <button class="subnavbtn">Verkooporders <i class="fa fa-caret-down"></i></button>
      <div class="subnav-content">
        <a href="bas-create-Verkooporders1.php">Verkoopor Toevoegen</a>
        <a href="bas-update-Verkooporder1.php">Verkoopor Update</a>
        <a href="bas-read-Verkooporder.php">Verkoopor Read</a>
        <a href="bas-delete-Verkooporders1.php">Verkoopor Verwijderen</a>
        <a href="bas-search-Verkooporder1.php">Verkoopor Zoeken</a>
      </div>
    </div>
    <div class="subnav">
      <button class="subnavbtn">leveranciers <i class="fa fa-caret-down"></i></button>
      <div class="subnav-content">
        <a href="bas-create-leveranciers1.php">leverancier Toevoegen</a>
        <a href="bas-update-leveranciers1.php">leverancier Update</a>
        <a href="bas-read-leveranciers.php">leveranciers Read</a>
        <a href="bas-delete-leveranciers1.php">leverancier Verwijderen</a>
        <a href="bas-search-leveranciers1.php">leverancier Zoeken</a>
      </div>
    </div>
    <a href="#contact">Contact</a>
  </div>
</header>

<body>
  <div class="top-section">
    <img class="logo" src="../logo.png" alt="">
  </div>
  <nav>

  </nav>
  <div class="welkom">

    <?php
    session_start();
    echo "<h2>" . "Welkom " . $_SESSION['gebruiker']->gebruikernaam;
    "<h2>" ?>

  </div>
  <form class="d-flex">
    <button class="btn-uit"><a href="../bas-inloggen1.php">UITLOGGEN</a></button>
  </form>
  <div class="addgebruiker">
    <a href="bas-create-gebruiker1.php"><i class="fa fa-user-plus" aria-hidden="true" style="font-size:27px;"></i></a>
  </div>
</body>

</html>