<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>
    <?php

require_once "gar-connect.php";
require_once "artikel-class.php";

if (isset($_POST['artId'])) {
    // Haal het artikel-ID op uit het formulier
    $artId = $_POST['artId'];

    // Maak een nieuw Artikel-object met het artikel-ID
    $artikel = new Artikel($artId, "", 0, 0, 0, 0, 0, "", 0);

    // Gebruik de getter-methoden om de huidige eigenschappen van het artikel op te halen
    $omschrijving = $artikel->getartId();
    $omschrijving = $artikel->getartOmschrijving();
    $inkoop = $artikel->getartInkoop();
    $verkoop = $artikel->getartVerkoop();
    $voorraad = $artikel->getartVoorraad();
    $minVoorraad = $artikel->getartMinVoorraad();
    $maxVoorraad = $artikel->getartMaxVoorraad();
    $locatie = $artikel->getartLocatie();
    $levId = $artikel->getlevId();

    global $conn;
    $artikeln = $conn->prepare("
select artId, artOmschrijving, artInkoop, artVerkoop, artVoorraad, artMinVoorraad, artMaxVoorraad, artLocatie, levId
from artikelen
where artId = :artId
");
    $artikeln->execute(["artId" => $artId]);

    //artikelgegevens in een nieuw formulier laten zien
    echo " <form class='form' action='bas-update3.php' method='post'>";
    foreach ($artikeln as $artikel) {
        // artikelkenteken mag niet gewijzigd worden
        echo "artId: <input type='text' ";
        echo "name='artId'";
        echo "value= '" . $artikel["artId"] . " '";
        echo " > <br />";

        echo "artOmschrijving: <input type='text' ";
        echo "name='artOmschrijving'";
        echo "value= '" . $artikel["artOmschrijving"] . "' ";
        echo " > <br />";

        echo "artInkoop: <input type='text' ";
        echo "name='artInkoop'";
        echo "value= '" . $artikel["artInkoop"] . "' ";
        echo " > <br />";

        echo "artVerkoop: <input type='text'";
        echo "name='artVerkoop'";
        echo "value= '" . $artikel["artVerkoop"] . "' ";
        echo " > <br />";

        echo "artVoorraad: <input type='text' ";
        echo "name='artVoorraad'";
        echo "value= '" . $artikel["artVoorraad"] . "' ";
        echo " > <br />";

        echo "artMinVoorraad: <input type='text' ";
        echo "name='artMinVoorraad'";
        echo "value= '" . $artikel["artMinVoorraad"] . "' ";
        echo " > <br />";

        echo "artMaxVoorraad: <input type='text' ";
        echo "name='artMaxVoorraad'";
        echo "value= '" . $artikel["artMaxVoorraad"] . "' ";
        echo " > <br />";

        echo "artLocatie: <input type='text' ";
        echo "name='artLocatie'";
        echo "value= '" . $artikel["artLocatie"] . "' ";
        echo " > <br />";

        echo "levId: <input type='text' ";
        echo "name='levId'";
        echo "value=" . $artikel["levId"] . "";
        echo "> <br />";
    }
    echo "<input type='submit' name='submit_button' value='Verzenden'>";
    echo "</form>";
    echo "</div>";


    exit();
}
?>
