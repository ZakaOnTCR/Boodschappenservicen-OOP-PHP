<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>

<div class="container">
<table class="table table-dark table-hover">
            <tr>
                <th>artOmschrijving</th>
                <th>artInkoop</th>
                <th>artVerkoop</th>
                <th>artVoorraad</th>
                <th>artMinVoorraad</th>
                <th>artMaxVoorraad</th>
                <th>artLocatie</th>
            </tr>

<?php
// artikelkenteken uit het formulier halen
$artId = $_POST["artId"];

// klantgegevens uit de tabel halen
require_once "gar-connect.php";
global $conn;
$artikeln = $conn->prepare("
select artOmschrijving, artInkoop, artVerkoop, artVoorraad, artMinVoorraad, artMaxVoorraad, artLocatie
from artikelen
where artId = :artId
");
$artikeln->execute(["artId" => $artId]);

// artikelgegevens laten zien


foreach ($artikeln as $artikel)
{
    echo "<tr>";
    echo "<form class='form' action='bas-delet-artiekl3.php' method='post'>";
    echo "<td>" . $artikel["artOmschrijving"] . "</td>";
    echo "<td>" . $artikel["artInkoop"] . "</td>";
    echo "<td>" . $artikel["artVerkoop"] . "</td>";
    echo "<td>" . $artikel["artVoorraad"] . "</td>";
    echo "<td>" . $artikel["artMinVoorraad"] . "</td>";
    echo "<td>" . $artikel["artMaxVoorraad"] . "</td>";
    echo "<td>" . $artikel["artLocatie"] . "</td>";
    echo "</tr>";
    echo "</form>";
}
echo "</table><br />";
?>
<form action="bas-delet-artikel3.php" method="post">
   <h4>wil je de arId verwideren <h2> <input type='text' name='artId' value = <?php echo  $artId?>>
    <input class='verwijder' type='submit' value="verwijderen">
</form>
</div>

</body>
</html>