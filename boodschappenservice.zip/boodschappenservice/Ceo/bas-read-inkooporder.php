<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>


    <div class="container">
        <div class="tbl-header">
            <table cellpadding="0" cellspacing="0" border="0">
                <thead>
                    <tr>
                        <th>levId</th>
                        <th>artId</th>
                        <th>inkOrdDatum</th>
                        <th>inkOrdBestAantal</th>
                        <th>inkOrdStatus</th>
                    </tr>
                </thead>
                <?php
                require_once "gar-connect.php";

                require_once "inkooporders-class.php";

                // Step 1: Create a SQL query to retrieve all the data from the "inkooporders" table
                $sql = "SELECT * FROM inkooporders";

                // Step 2: Prepare the SQL query using PDO
                $stmt = $conn->prepare($sql);

                // Step 3: Execute the SQL query
                $stmt->execute();

                // Step 4: Fetch the results and create Article objects for each row in the "inkooporders" table
                $inkooporders = array();
                while ($row = $stmt->fetch()) {
                    $inkooporder = new inkooporder($row["inkOrdId"], $row["levId"], $row["artId"], $row["inkOrdDatum"], $row["inkOrdBestAantal"], $row["inkOrdStatus"]);
                    array_push($inkooporders, $inkooporder);
                }

                // Step 5: Display the data in HTML table format
                

                foreach ($inkooporders as $inkooporder) {
                    echo "<tr>";
                    echo "<td>" . $inkooporder->getlevId() . "</td>";
                    echo "<td>" . $inkooporder->getartId() . "</td>";
                    echo "<td>" . $inkooporder->getinkOrdDatum() . "</td>";
                    echo "<td>" . $inkooporder->getinkOrdBestAantal() . "</td>";
                    echo "<td>" . $inkooporder->getinkOrdStatus() . "</td>";
                    echo "</tr>";
                }

                echo "</table>";

                ?>
        </div>

</body>

</html>