<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

    <?php

    require_once "gar-connect.php";
    require_once "verkooporders-class.php";



    // Haal de waarden op uit het formulier

   

    // Maak een nieuw artikel object met de nieuwe waarden
    $Verkooporder = new Verkooporder();

    $Verkooporder->update();





    ?>

</div>