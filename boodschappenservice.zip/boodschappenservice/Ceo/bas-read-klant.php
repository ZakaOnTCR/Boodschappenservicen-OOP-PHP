<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>


    <div class="container">
        <div class="tbl-header">
            <table cellpadding="0" cellspacing="0" border="0">
                <thead>
                    <tr>
                        <th>klantnaam</th>
                        <th>klantemail</th>
                        <th>klantadres</th>
                        <th>klantpostcode</th>
                        <th>klantwoonplaats</th>
                    </tr>
                </thead>

        </div>
        <?php
        require_once "gar-connect.php";

        require_once "klant-class.php";

        // Step 1: Create a SQL query to retrieve all the data from the "klanten" table
        $sql = "SELECT * FROM klanten";

        // Step 2: Prepare the SQL query using PDO
        $stmt = $conn->prepare($sql);

        // Step 3: Execute the SQL query
        $stmt->execute();

        // Step 4: Fetch the results and create Article objects for each row in the "klanten" table
        $klanten = array();
        while ($row = $stmt->fetch()) {
            $klant = new klant($row["klantid"], $row["klantnaam"], $row["klantemail"], $row["klantadres"], $row["klantpostcode"], $row["klantwoonplaats"]);
            array_push($klanten, $klant);
        }

        // Step 5: Display the data in HTML table format
        

        foreach ($klanten as $klant) {
            echo "<tr>";
            echo "<td>" . $klant->getklantnaam() . "</td>";
            echo "<td>" . $klant->getklantemail() . "</td>";
            echo "<td>" . $klant->getklantadres() . "</td>";
            echo "<td>" . $klant->getklantpostcode() . "</td>";
            echo "<td>" . $klant->getklantwoonplaats() . "</td>";
            echo "</tr>";
        }

        echo "</table>";

        ?>

</body>

</html>