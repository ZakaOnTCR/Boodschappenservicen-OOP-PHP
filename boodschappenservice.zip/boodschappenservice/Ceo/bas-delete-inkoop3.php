<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

    <?php
    require_once('inkooporders-class.php'); // Inclusief de Artikel-klasse
    require_once('gar-connect.php'); // Inclusief de database-configuratie
    
    $inkooporder = new inkooporder(null, null, null, null, null, null);

    if (isset($_POST['inkOrdId'])) {
        $inkooporder->inkOrdId = $_POST['inkOrdId'];

        // DELETE query uitvoeren
        $query = "DELETE FROM inkooporders WHERE inkOrdId = :inkOrdId";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':inkOrdId', $inkooporder->inkOrdId);
        $stmt->execute();

        echo "inkooporder met ID " . $inkooporder->inkOrdId . " is succesvol verwijderd.";
    } else {
        echo "Geen inkooporder ID opgegeven.";
    }
    ?>

</div>