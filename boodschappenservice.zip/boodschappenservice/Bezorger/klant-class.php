<?php
class Klant
{
    public $klantid;
    public $klantnaam;
    public $klantemail;
    public $klantadres;
    public $klantpostcode;
    public $klantwoonplaats;

    public function __construct($klantid, $klantnaam, $klantemail, $klantadres, $klantpostcode, $klantwoonplaats)
    {
        $this->klantid = NULL;
        $this->klantnaam = $klantnaam;
        $this->klantemail = $klantemail;
        $this->klantadres = $klantadres;
        $this->klantpostcode = $klantpostcode;
        $this->klantwoonplaats = $klantwoonplaats;
    }

    public function getklantid()
    {
        return $this->klantid;
    }

    public function getklantnaam()
    {
        return $this->klantnaam;
    }

    public function getklantemail()
    {
        return $this->klantemail;
    }

    public function getklantadres()
    {
        return $this->klantadres;
    }

    public function getklantpostcode()
    {
        return $this->klantpostcode;
    }

    public function getklantwoonplaats()
    {
        return $this->klantwoonplaats;
    }
}