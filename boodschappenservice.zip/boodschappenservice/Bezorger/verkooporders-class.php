<?php
class verkooporder
{
    public $verkOrdId;
    public $klantid;
    public $artId;
    public $verkOrdDatum;
    public $verkOrdBestAantal;
    public $verkOrdStatus;


    // Constructor to initialize the article object
    public function __construct($verkOrdId, $klantid, $artId, $verkOrdDatum, $verkOrdBestAantal, $verkOrdStatus)
    {
        $this->verkOrdId = NULL;
        $this->klantid = $klantid;
        $this->artId = $artId;
        $this->verkOrdDatum = $verkOrdDatum;
        $this->verkOrdBestAantal = $verkOrdBestAantal;
        $this->verkOrdStatus = $verkOrdStatus;
    }

    

    // Getter methods
    public function getverkOrdId()
    {
        return $this->verkOrdId;
    }
    public function getklantid()
    {
        return $this->klantid;
    }
    public function getartId()
    {
        return $this->artId;
    }
    public function getverkOrdDatum()
    {
        return $this->verkOrdDatum;
    }
    public function getverkOrdBestAantal()
    {
        return $this->verkOrdBestAantal;
    }
    public function getverkOrdStatus()
    {
        return $this->verkOrdStatus;
    }
}