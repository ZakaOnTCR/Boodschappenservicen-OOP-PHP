<?php require_once "navbar.php" ?>


<?php


session_start();
if (isset($_SESSION['gebruiker'])) {
    if ($_SESSION['gebruiker']->gebruikerrol === "Magazijnmeester"){
        echo "<div class='contact-form'>";
        echo "Welkom " . $_SESSION['gebruiker']->gebruikernaam;
        echo "<form><button type='submit' name='loguit'>uitloggen</button></form>";
        echo "<a href='profiel1.php'>profile</a>";
        echo "</div>";
    }elseif ($_SESSION['gebruiker']->gebruikerrol === "Verkoper"){
        echo "Welkom " . $_SESSION['gebruiker']->gebruikernaam;
        echo "<form><button type='submit' name='loguit'>uitloggen</button></form>";
        echo "<a href='profiel1.php'>profile</a>";
    }elseif ($_SESSION['gebruiker']->gebruikerrol === "Magazijnmedewerker"){
        echo "Welkom " . $_SESSION['gebruiker']->gebruikernaam;
        echo "<form><button type='submit' name='loguit'>uitloggen</button></form>";
        echo "<a href='profiel1.php'>profile</a>";
    }
    elseif ($_SESSION['gebruiker']->gebruikerrol === "Bezorger"){
        echo "Welkom " . $_SESSION['gebruiker']->gebruikernaam;
        echo "<form><button type='submit' name='loguit'>uitloggen</button></form>";
        echo "<a href='profiel1.php'>profile</a>";
    }
    elseif ($_SESSION['gebruiker']->gebruikerrol === "Inkoper"){
        echo "Welkom " . $_SESSION['gebruiker']->gebruikernaam;
        echo "<form><button type='submit' name='loguit'>uitloggen</button></form>";
        echo "<a href='profiel1.php'>profile</a>";
    }
    else{
        header("location:http://localhost/Boodschappenservice/bas-inloggen1.php" , true);
        die("");
    }
}else{
    header("location:http://localhost/Boodschappenservice/bas-inloggen1.php" , true);
    die("");
}
if (isset($_GET['loguit'])) {
    session_unset();
    session_destroy();
    header("location:http://localhost/Boodschappenservice/bas-inloggen1.php" , true);
}
