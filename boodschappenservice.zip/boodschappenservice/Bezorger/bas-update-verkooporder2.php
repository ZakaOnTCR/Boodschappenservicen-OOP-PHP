<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>
    <?php

require_once "gar-connect.php";
require_once "verkooporders-class.php";

if (isset($_POST['verkOrdId'])) {
    // Haal het verkooporder-ID op uit het formulier
    $verkOrdId = $_POST['verkOrdId'];

    // Maak een nieuw verkooporder-object met het verkooporder-ID
    $verkooporder = new verkooporder($verkOrdId, "", 0, 0, 0, 0, 0, "", 0);

    // Gebruik de getter-methoden om de huidige eigenschappen van het verkooporder op te halen
    $klantid = $verkooporder->getklantid();
    $artId = $verkooporder->getartId();
    $verkOrdDatum = $verkooporder->getverkOrdDatum();
    $verkOrdBestAantal = $verkooporder->getverkOrdBestAantal();
    $verkOrdStatus = $verkooporder->getverkOrdStatus();

    global $conn;
    $verkooporders = $conn->prepare("
select verkOrdId, klantid, artId, verkOrdDatum, verkOrdBestAantal, verkOrdStatus
from verkooporders
where verkOrdId = :verkOrdId
");
    $verkooporders->execute(["verkOrdId" => $verkOrdId]);

    //verkoopordergegevens in een nieuw formulier laten zien
    echo " <form class='form' action='bas-update-verkooporder3.php' method='post'>";
    foreach ($verkooporders as $verkooporder) {
        // verkooporderkenteken mag niet gewijzigd worden
        echo "verkOrdId: <input type='text' ";
        echo "name='verkOrdId'";
        echo "value= '" . $verkooporder["verkOrdId"] . " '";
        echo " > <br />";

        echo "klantid: <input type='text' ";
        echo "name='klantid'";
        echo "value= '" . $verkooporder["klantid"] . "' ";
        echo " > <br />";

        echo "artId: <input type='text' ";
        echo "name='artId'";
        echo "value= '" . $verkooporder["artId"] . "' ";
        echo " > <br />";

        echo "verkOrdDatum: <input type='text'";
        echo "name='verkOrdDatum'";
        echo "value= '" . $verkooporder["verkOrdDatum"] . "' ";
        echo " > <br />";

        echo "verkOrdBestAantal: <input type='text' ";
        echo "name='verkOrdBestAantal'";
        echo "value= '" . $verkooporder["verkOrdBestAantal"] . "' ";
        echo " > <br />";

        echo "verkOrdStatus: <input type='text' ";
        echo "name='verkOrdStatus'";
        echo "value= '" . $verkooporder["verkOrdStatus"] . "' ";
        echo " > <br />";

    }
    echo "<input type='submit' name='submit_button' value='Verzenden'>";
    echo "</form>";
    echo "</div>";


    exit();
}
?>

