<?php
class Verkooporder
{
    public $verkOrdId;
    public $klantid;
    public $artId;
    public $verkOrdDatum;
    public $verkOrdBestAantal;
    public $verkOrdStatus;


    // Constructor to initialize the article object
    public function __construct($verkOrdId=NULL, $klantid=NULL, $artId=NULL, $verkOrdDatum=NULL, $verkOrdBestAantal=NULL, $verkOrdStatus=NULL)
    {
        $this->verkOrdId = NULL;
        $this->klantid = $klantid;
        $this->artId = $artId;
        $this->verkOrdDatum = $verkOrdDatum;
        $this->verkOrdBestAantal = $verkOrdBestAantal;
        $this->verkOrdStatus = $verkOrdStatus;
    }

    // Getter methods
    public function getverkOrdId()
    {
        return $this->verkOrdId;
    }
    public function getklantid()
    {
        return $this->klantid;
    }
    public function getartId()
    {
        return $this->artId;
    }
    public function getverkOrdDatum()
    {
        return $this->verkOrdDatum;
    }
    public function getverkOrdBestAantal()
    {
        return $this->verkOrdBestAantal;
    }
    public function getverkOrdStatus()
    {
        return $this->verkOrdStatus;
    }


    public function setverkOrdId()
    {
        return $this->verkOrdId;
    }
    public function setklantid()
    {
        return $this->klantid;
    }
    public function setartId()
    {
        return $this->artId;
    }
    public function setverkOrdDatum()
    {
        return $this->verkOrdDatum;
    }
    public function setverkOrdBestAantal()
    {
        return $this->verkOrdBestAantal;
    }
    public function setverkOrdStatus()
    {
        return $this->verkOrdStatus;
    }
    public function create()
    {
        require "gar-connect.php";

        // Retrieve the form data using the $_POST superglobal
        $klantid = $_POST['klantid'];
        $artId = $_POST['artId'];
        $verkOrdDatum = $_POST['verkOrdDatum'];
        $verkOrdBestAantal = $_POST['verkOrdBestAantal'];
        $verkOrdStatus = $_POST['verkOrdStatus'];

        // Create a new Verkooporder object with the form data
        $verkooporder = new Verkooporder(NULL, $klantid, $artId, $verkOrdDatum, $verkOrdBestAantal, $verkOrdStatus);

        // Insert the Verkooporder into the database
        $sql = $conn->prepare("INSERT INTO verkooporders (klantid, artId, verkOrdDatum, verkOrdBestAantal, verkOrdStatus) VALUES (:klantid, :artId, :verkOrdDatum, :verkOrdBestAantal, :verkOrdStatus)");
        $sql->execute(
            [
                "klantid" => $verkooporder->klantid,
                "artId" => $verkooporder->artId,
                "verkOrdDatum" => $verkooporder->verkOrdDatum,
                "verkOrdBestAantal" => $verkooporder->verkOrdBestAantal,
                "verkOrdStatus" => $verkooporder->verkOrdStatus,
            ]
        );

        echo "Verkooporder succesvol aangemaakt!";
    }



    public function update()
    {
        require "gar-connect.php";

        $verkOrdId = $_POST['verkOrdId'];
        $klantid = $_POST['klantid'];
        $artId = $_POST['artId'];
        $verkOrdDatum = $_POST['verkOrdDatum'];
        $verkOrdBestAantal = $_POST['verkOrdBestAantal'];
        $verkOrdStatus = $_POST['verkOrdStatus'];


        // Maak een nieuw artikel object met de nieuwe waarden
        $artikel = new Verkooporder($verkOrdId, $klantid, $artId, $verkOrdDatum, $verkOrdBestAantal, $verkOrdStatus);

        // Update het artikel in de database
        $sql = $conn->prepare("UPDATE verkooporders SET klantid =:klantid , artId =:artId , verkOrdDatum=:verkOrdDatum, verkOrdBestAantal=:verkOrdBestAantal, verkOrdStatus=:verkOrdStatus WHERE verkOrdId =:verkOrdId ");
        $sql->execute(
            [
                "verkOrdId" => $verkOrdId,
                "klantid" => $klantid,
                "artId" => $artId,
                "verkOrdDatum" => $verkOrdDatum,
                "verkOrdBestAantal" => $verkOrdBestAantal,
                "verkOrdStatus" => $verkOrdStatus,
            ]
        );

        echo "Verkooporder succesvol geüpdatet!";
    }

    public function delete()
    {
        require "gar-connect.php";

        // Delete the Verkooporder from the database
        $sql = $conn->prepare("DELETE FROM verkooporders WHERE verkOrdId = :verkOrdId");
        $sql->execute(["verkOrdId" => $this->verkOrdId]);

        echo "Verkooporder met ID " . $this->verkOrdId . " is succesvol verwijderd!";
    }


    public function read()
    {
        require "gar-connect.php";
    
        $sql = $conn->prepare("SELECT * FROM verkooporders");
        $sql->execute();

        //uitlezen aary 
        foreach($sql as $Verkooporder)
        {
            echo "<tr>";
            echo "<td>". $this->verkOrdId=$Verkooporder ["klantid"]. "-";
            echo "<td>". $this->klantid=$Verkooporder ["klantid"]. "-";
            echo "<td>". $this->artId=$Verkooporder ["artId"]. "-";
            echo "<td>". $this->verkOrdDatum=$Verkooporder ["verkOrdDatum"]. "-";
            echo "<td>". $this->verkOrdBestAantal=$Verkooporder ["verkOrdBestAantal"]. "-";
            echo "<td>". $this->verkOrdStatus=$Verkooporder ["verkOrdStatus"]. "-";
            echo "</tr>";
        }

    }

    public function afdrukkenVerkooporder()
    {
        echo "<table class='table table-dark table-hover'>";
        echo "<tr>";
        echo "<td>" . "verkOrdId: " . $this->verkOrdId . "<br>" . "</td>";
        echo "<td>" . "klantid: " . $this->klantid . "</td>" . "<br>";
        echo "<td>" . "artId: " . $this->artId . "</td>" . "<br>";
        echo "<td>" . "verkOrdDatum: " . $this->verkOrdDatum . "</td>" . "<br>";
        echo "<td>" . "verkOrdBestAantal: " . $this->verkOrdBestAantal . "</td>" . "<br>";
        echo "<td>" . "verkOrdStatus: " . $this->verkOrdStatus . "</td>" . "<br>";
        echo "</tr>";
        echo "</table>";
    }


    public function searchVerkoper($verkOrdId)
    {
        require "gar-connect.php";
        $sql = $conn->prepare("
        select * from verkooporders
        where verkOrdId=:verkOrdId
        ");
        $sql->bindParam(":verkOrdId", $verkOrdId);
        $sql->execute();

        foreach ($sql as $verkooporder) {
            $this->klantid = $verkooporder["klantid"];
            $this->artId = $verkooporder["artId"];
            $this->verkOrdDatum = $verkooporder["verkOrdDatum"];
            $this->verkOrdBestAantal = $verkooporder["verkOrdBestAantal"];
            $this->verkOrdStatus = $verkooporder["verkOrdStatus"];
        }

        echo $verkOrdId;



    }
}