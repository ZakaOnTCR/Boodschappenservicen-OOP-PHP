<?php
require_once('klant-class.php'); // Inclusief de Artikel-klasse
require_once('gar-connect.php'); // Inclusief de database-configuratie

$klant = new Klant(null, null, null, null, null, null, null, null, null);

if(isset($_POST['klantid'])) {
    $klant->klantid = $_POST['klantid'];
    
    // DELETE query uitvoeren
    $query = "DELETE FROM klanten WHERE klantid = :klantid";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':klantid', $klant->klantid);
    $stmt->execute();

    echo "klant met ID " . $klant->klantid . " is succesvol verwijderd.";
} else {
    echo "Geen klant ID opgegeven.";
}
?>