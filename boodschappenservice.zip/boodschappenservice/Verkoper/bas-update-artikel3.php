<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

    <?php

    require_once "gar-connect.php";
    require_once "artikel-class.php";



    // Haal de waarden op uit het formulier
    $artId = $_POST['artId'];
    $artOmschrijving = $_POST['artOmschrijving'];
    $artInkoop = $_POST['artInkoop'];
    $artVerkoop = $_POST['artVerkoop'];
    $artVoorraad = $_POST['artVoorraad'];
    $artMinVoorraad = $_POST['artMinVoorraad'];
    $artMaxVoorraad = $_POST['artMaxVoorraad'];
    $artLocatie = $_POST['artLocatie'];
    $levId = $_POST['levId'];

    // Maak een nieuw artikel object met de nieuwe waarden
    $artikel = new Artikel($artId, $artOmschrijving, $artInkoop, $artVerkoop, $artVoorraad, $artMinVoorraad, $artMaxVoorraad, $artLocatie, $levId);

    // Update het artikel in de database
    $sql = $conn->prepare("UPDATE artikelen SET artOmschrijving=:artOmschrijving, artInkoop=:artInkoop, artVerkoop=:artVerkoop, artVoorraad=:artVoorraad, artMinVoorraad=:artMinVoorraad, artMaxVoorraad=:artMaxVoorraad, artLocatie=:artLocatie, levId=:levId WHERE artId=:artId");
    $sql->execute(
        [
            "artId" => $artId,
            "artOmschrijving" => $artOmschrijving,
            "artInkoop" => $artInkoop,
            "artVerkoop" => $artVerkoop,
            "artVoorraad" => $artVoorraad,
            "artMinVoorraad" => $artMinVoorraad,
            "artMaxVoorraad" => $artMaxVoorraad,
            "artLocatie" => $artLocatie,
            "levId" => $levId,
        ]
    );

    echo "Artikel succesvol geüpdatet!";




    ?>

</div>