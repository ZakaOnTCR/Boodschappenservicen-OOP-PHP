<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>

    <div class="container">
        <table class="table table-dark table-hover">
            <tr>
                <th>klantid</th>
                <th>klantnaam</th>
                <th>klantemail</th>
                <th>klantadres</th>
                <th>klantpostcode</th>
                <th>klantwoonplaats</th>
            </tr>

            <?php
            // artikelkenteken uit het formulier halen
            $klantid = $_POST["klantid"];

            require_once "gar-connect.php";
            global $conn;
            $klanten = $conn->prepare("
select klantid, klantnaam, klantemail, klantadres, klantpostcode, klantwoonplaats
from klanten
where klantid = :klantid
");
            $klanten->execute(["klantid" => $klantid]);

            // artikelgegevens laten zien


            foreach ($klanten as $klant) {
                echo "<tr>";
                echo "<form class='form' action='bas-delet3-klant.php' method='post'>";
                echo "<td>" . $klant["klantid"] . "</td>";
                echo "<td>" . $klant["klantnaam"] . "</td>";
                echo "<td>" . $klant["klantemail"] . "</td>";
                echo "<td>" . $klant["klantadres"] . "</td>";
                echo "<td>" . $klant["klantpostcode"] . "</td>";
                echo "<td>" . $klant["klantwoonplaats"] . "</td>";
                echo "</tr>";
                echo "</form>";
            }
            echo "</table><br />";
            ?>
            <form action="bas-delet3-klant.php" method="post">
                <h4>Wil je de klant verwijderen?</h4>
                <input type='hidden' name='klantid' value='<?php echo $klantid; ?>'>
                <input type='submit' value='Verwijderen'>
            </form>
    </div>

</body>

</html>