<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

	<?php

	require_once "gar-connect.php";
	require_once "verkooporders-class.php";



	// Haal de waarden op uit het formulier
	

	// Maak een nieuw artikel object met de nieuwe waarden
	




	if ($_SERVER["REQUEST_METHOD"] == "POST") {

		$verkOrdId = $_POST['verkOrdId'];
		$klantid = $_POST['klantid'];
		$artId = $_POST['artId'];
		$verkOrdDatum = $_POST['verkOrdDatum'];
		$verkOrdBestAantal = $_POST['verkOrdBestAantal'];
		$verkOrdStatus = $_POST['verkOrdStatus'];


		// Maak een nieuw artikel object met de nieuwe waarden
		// Create new Verkooporder object and set its properties
		$verkooporder = new Verkooporder($verkOrdId, $klantid, $artId, $verkOrdDatum, $verkOrdBestAantal, $verkOrdStatus);



		// Call the update function on the Verkooporder object
		$result = $verkooporder->update();




	}

	?>

</div>