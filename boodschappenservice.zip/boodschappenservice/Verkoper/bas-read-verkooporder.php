<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>


    <div class="container">
        <table class="table table-dark table-hover">
            <tr>
                <th>verkOrdId</th>
                <th>klantid</th>
                <th>artId</th>
                <th>verkOrdDatum</th>
                <th>verkOrdBestAantal</th>
                <th>verkOrdStatus</th>
            </tr>
            <?php
            require_once "gar-connect.php";

            require "verkooporders-class.php";

            // Step 1: Create a SQL query to retrieve all the data from the "Verkooporders" table
            $verkooporder = new Verkooporder(NULL, NULL, NULL, NULL, NULL, NULL);
            // Call the delete method to delete the Verkooporder from the database
            $verkooporder->read();

            echo "</table>";
            ?>

</body>

</html>