<!DOCTYPE html>
<html lang="en">

<body>

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../main.css">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <title>Document</title>

    </head>

    <header>


    </header>

    <div class="top-section">
        <img class="logo" src="../logo.png" alt="">
    </div>
    <nav>
        <ul>
            <div class="icon">
                <i class="fa fa-home" aria-hidden="true"></i>
                <li><a href="#">Home pagaina</a></li>
            </div>
            <div class="icon">
            <i class="fa fa-book" aria-hidden="true"></i>
                <li><a href="bas-read-artikel.php">artikel read</a></li>
            </div>
            
            <div class="icon">
                <i class="fa fa-search" aria-hidden="true"></i>
                <li><a href="bas-search-artikel1.php">artikel zoeken</a></li>
            </div>
            <div class="icon">
                <i class="fa fa-pencil" aria-hidden="true"></i>
                <li><a href="bas-update-artikel1.php">artikel update</a></li>
            </div>
            
            <div class="icon">
            <i class="fa fa-plus" aria-hidden="true"></i>
                <li><a href="bas-create-klant1.php">klant toevoegen</a></li>
            </div>

            <div class="icon">
            <i class="fa fa-book" aria-hidden="true"></i>
                <li><a href="bas-read-klant.php">klant read</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-search" aria-hidden="true"></i>
                <li><a href="bas-search1-klant.php">klant zoeken</a></li>
            </div>
            <div class="icon">
                <i class="fa fa-trash" aria-hidden="true"></i>
                <li><a href="bas-delet-klant1.php">kalnt verwijderen</a></li>
            </div>

            <div class="icon">
            <i class="fa fa-plus" aria-hidden="true"></i>
                <li><a href="bas-create-verkooporders1.php">verkooporder toevoegen</a></li>
            </div>

            <div class="icon">
            <i class="fa fa-book" aria-hidden="true"></i>
                <li><a href="bas-read-verkooporder.php">verkooporder read</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-search" aria-hidden="true"></i>
                <li><a href="bas-search-verkooporder1.php">verkooporder zoeken</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-trash" aria-hidden="true"></i>
                <li><a href="bas-delete-verkooporders1.php">verkooporder verwijderen</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-pencil" aria-hidden="true"></i>
                <li><a href="bas-update-verkooporder1.php">verkooporder update</a></li>
            </div>
        </ul>
    </nav>
    <div class="welkom">

        <?php
        session_start();
        echo "<h2>" . "Welkom " . $_SESSION['gebruiker']->gebruikernaam;
        "<h2>" ?>

    </div>


</body>

</html>