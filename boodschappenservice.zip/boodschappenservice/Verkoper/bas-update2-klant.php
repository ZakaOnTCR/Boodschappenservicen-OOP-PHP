<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>
    <?php

    require_once "gar-connect.php";
    require_once "klant-class.php";
    
    if (isset($_POST['klantid'])) {
        // Haal het klant-ID op uit het formulier
        $klantid = $_POST['klantid'];
    
        // Maak een nieuw Klant-object met het klant-ID
        $klant = new Klant($klantid, "", "", "", "", "");
    
        // Gebruik de getter-methoden om de huidige eigenschappen van de klant op te halen
        $klantnaam = $klant->getKlantnaam();
        $klantemail = $klant->getKlantemail();
        $klantadres = $klant->getKlantadres();
        $klantpostcode = $klant->getKlantpostcode();
        $klantwoonplaats = $klant->getKlantwoonplaats();
    
        global $conn;
        $klanten = $conn->prepare("
    select klantid, klantnaam, klantemail, klantadres, klantpostcode, klantwoonplaats
    from klanten
    where klantid = :klantid
    ");
        $klanten->execute(["klantid" => $klantid]);
    
        // Klantgegevens in een nieuw formulier laten zien
        echo " <form class='form' action='bas-update3-klant.php' method='post'>";
        foreach ($klanten as $klant) {
            // klantid mag niet gewijzigd worden
            echo "klantid: <input type='text' ";
            echo "name='klantid'";
            echo "value= '" . $klant["klantid"] . " '";
            echo " readonly> <br />";
    
            echo "klantnaam: <input type='text' ";
            echo "name='klantnaam'";
            echo "value= '" . $klant["klantnaam"] . "' ";
            echo " > <br />";
    
            echo "klantemail: <input type='text' ";
            echo "name='klantemail'";
            echo "value= '" . $klant["klantemail"] . "' ";
            echo " > <br />";
    
            echo "klantadres: <input type='text'";
            echo "name='klantadres'";
            echo "value= '" . $klant["klantadres"] . "' ";
            echo " > <br />";
    
            echo "klantpostcode: <input type='text' ";
            echo "name='klantpostcode'";
            echo "value= '" . $klant["klantpostcode"] . "' ";
            echo " > <br />";
    
            echo "klantwoonplaats: <input type='text' ";
            echo "name='klantwoonplaats'";
            echo "value= '" . $klant["klantwoonplaats"] . "' ";
            echo " > <br />";
        }
        echo "<input type='submit' name='submit_button' value='Verzenden'>";
        echo "</form>";
        echo "</div>";
    
        exit();
    }
    ?>
    