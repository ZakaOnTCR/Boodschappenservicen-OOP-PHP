<!DOCTYPE html>
<html lang="en">

<body>

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../main.css">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <title>Document</title>

    </head>

    <header>


    </header>

    <div class="top-section">
        <img class="logo" src="../logo.png" alt="">
    </div>
    <nav>
        <ul>
            <div class="icon">
                <i class="fa fa-home" aria-hidden="true"></i>
                <li><a href="#">Home pagaina</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-plus" aria-hidden="true"></i>
                <li><a href="bas-create-inkoop1.php">inkooporders toevoegen</a></li>
            </div>


            <div class="icon">
                <i class="fa fa-book" aria-hidden="true"></i>
                <li><a href="bas-read-inkooporder.php">inkooporders read</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-search" aria-hidden="true"></i>
                <li><a href="bas-search-inkoop1.php">inkooporders zoeken</a></li>
            </div>
            <div class="icon">
                <i class="fa fa-pencil" aria-hidden="true"></i>
                <li><a href="bas-update-inkoop1.php">inkooporders update</a></li>
            </div>

             <div class="icon">
                <i class="fa fa-trash" aria-hidden="true"></i>
                <li><a href="bas-delete-inkoop1.php">inkooporders verwijderen</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-plus" aria-hidden="true"></i>
                <li><a href="bas-create-leveranciers1.php">leverancier toevoegen</a></li>
            </div>


            <div class="icon">
                <i class="fa fa-book" aria-hidden="true"></i>
                <li><a href="bas-read-leveranciers.php">leveranciers read</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-search" aria-hidden="true"></i>
                <li><a href="bas-search-leveranciers1.php">leverancier zoeken</a></li>
            </div>
            <div class="icon">
                <i class="fa fa-pencil" aria-hidden="true"></i>
                <li><a href="bas-update-leveranciers1.php">leverancier update</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-trash" aria-hidden="true"></i>
                <li><a href="bas-delete-leveranciers1.php">leverancier verwijderen</a></li>
            </div>


        </ul>
    </nav>
    <div class="welkom">

        <?php
        session_start();
        echo "<h2>" . "Welkom " . $_SESSION['gebruiker']->gebruikernaam;
        "<h2>" ?>

    </div>
    <form class="d-flex">
        <button class="btn-uit"><a href="../bas-inloggen1.php">UITLOGGEN</a></button>
    </form>


</body>

</html>