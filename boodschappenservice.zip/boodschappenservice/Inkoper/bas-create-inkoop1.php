<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../main.css">
  <title>Document</title>

</head>

<body>


  <?php require_once("navbar.php") ?>

  <form class="form" action="bas-create-inkoop2.php" method="post">
    <div>
      <label for="levId ">levId:</label>
      <input type="text" id="levId" name="levId">
    </div>
    <div>
      <label for="artId ">artId:</label>
      <input type="text" id="artId" name="artId">
    </div>
    <div>
      <label for="inkOrdDatum">inkOrdDatum:</label>
      <input type="inkOrdDatum" id="inkOrdDatum" name="inkOrdDatum">
    </div>
    <div>
      <label for="inkOrdBestAantal">inkOrdBestAantal:</label>
      <input type="inkOrdBestAantal" id="inkOrdBestAantal" name="inkOrdBestAantal">
    </div>
    <div>
      <label for="inkOrdStatus">inkOrdStatus:</label>
      <input type="inkOrdStatus" id="inkOrdStatus" name="inkOrdStatus">
    </div>
    <input type="submit" value="Add Inkooporder">
  </form>
  

</body>

</html>