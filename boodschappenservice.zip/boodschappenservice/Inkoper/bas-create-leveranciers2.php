<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create leverancieren-2</title>
</head>
<body>
<?php require_once "navbar.php";?>
<div class="uitgevoerd">
<?php
require_once "leveranciers-class.php";

function addCustomer()
{
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$nieuwe_leveranciers = new leverancier(NULL, $_POST['levnaam'], $_POST['levcontact'], $_POST['levEmail'], $_POST['levAdres'], $_POST['levPostcode'], $_POST['levWoonplaats']);
    // Maak een SQL-query aan om de nieuwe leverancier toe te voegen
    $levnaam = $nieuwe_leveranciers->getlevnaam();
    $levcontact = $nieuwe_leveranciers->getlevcontact();
    $levEmail = $nieuwe_leveranciers->getlevEmail();
    $levAdres = $nieuwe_leveranciers->getlevAdres();
    $levPostcode = $nieuwe_leveranciers->getlevPostcode();
    $levWoonplaats = $nieuwe_leveranciers->getlevWoonplaats();

    require_once "gar-connect.php";

    $stmt = $conn->prepare("INSERT INTO leveranciers (levnaam, levcontact, levEmail, levAdres, levPostcode, levWoonplaats) VALUES (:levnaam, :levcontact, :levEmail, :levAdres, :levPostcode, :levWoonplaats)");

    $stmt->bindParam(':levnaam', $levnaam);
    $stmt->bindParam(':levcontact', $levcontact);
    $stmt->bindParam(':levEmail', $levEmail);
    $stmt->bindParam(':levAdres', $levAdres);
    $stmt->bindParam(':levPostcode', $levPostcode);
    $stmt->bindParam(':levWoonplaats', $levWoonplaats);

    // Voer de query uit en check het resultaat
    if ($stmt->execute()) {
        echo "<h2>leverancier toegevoegd!</p>";
    } else {
        echo "<p>Er is iets misgegaan. De leverancier is niet toegevoegd.</p>";
    }
    echo "<h1>". "<a class='terug' href='navbar.php'>Terug naar het menu. </a> . </h2>";
}
}

addCustomer();

?>
</div>

</body>
</html>