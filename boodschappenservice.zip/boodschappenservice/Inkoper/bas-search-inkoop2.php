<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>


<?php require_once "navbar.php" ?>
<div class="container">
<?php
require_once "gar-connect.php";
require_once "inkooporders-class.php";
// Verbinding maken met de database (vervang de waarden met die van jouw database)


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inkOrdId = $_POST["inkOrdId"];

    // Zoek het inkooporders in de database
    $stmt = $conn->prepare("SELECT * FROM inkooporders WHERE inkOrdId = :inkOrdId");
    $stmt->bindParam(":inkOrdId", $inkOrdId);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Toon de eigenschappen van het inkooporders als het gevonden is
    if ($result) {
        $inkooporders = new inkooporder($result["inkOrdId"], $result["levId"], $result["levId"], $result["inkOrdDatum"], $result["inkOrdBestAantal"],$result["inkOrdStatus"]);
        echo "<table class='table table-dark table-hover'>";
        echo "<tr>";
        echo "<td>" ."inkOrdId: " . $inkooporders->inkOrdId . "<br>" . "</td>";
        echo "<td>" ."levId: " . $inkooporders->levId ."</td>". "<br>";
        echo "<td>" ."inkOrdDatum: " . $inkooporders->inkOrdDatum ."</td>". "<br>";
        echo "<td>" ."inkOrdBestAantal: " . $inkooporders->inkOrdBestAantal ."</td>". "<br>";
        echo "<td>" ."inkOrdStatus: " . $inkooporders->inkOrdStatus ."</td>". "<br>";
        echo "</tr>";
        echo "</table>";
    } else {
        echo "inkooporders niet gevonden";
    }

}


$conn = null;
?>
</div>
</body>
</html>