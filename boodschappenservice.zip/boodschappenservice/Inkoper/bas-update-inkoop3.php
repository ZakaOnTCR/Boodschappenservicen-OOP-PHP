<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">
<?php

require_once "gar-connect.php";
require_once "inkooporders-class.php";

// Get values from the form
$inkOrdId = $_POST['inkOrdId'];
$levId = $_POST['levId'];
$artId = $_POST['artId'];
$inkOrdDatum = $_POST['inkOrdDatum'];
$inkOrdBestAantal = $_POST['inkOrdBestAantal'];
$inkOrdStatus = $_POST['inkOrdStatus'];

// Create a new inkooporder object with the new values
$inkooporder = new inkooporder($inkOrdId, $levId, $artId, $inkOrdDatum, $inkOrdBestAantal, $inkOrdStatus);

// Update the customer record in the database
$sql = $conn->prepare("UPDATE inkooporders SET levId=:levId, artId=:artId, inkOrdDatum=:inkOrdDatum, inkOrdBestAantal=:inkOrdBestAantal, inkOrdStatus=:inkOrdStatus WHERE inkOrdId=:inkOrdId");
$sql->execute([
    "inkOrdId" => $inkOrdId,
    "levId" => $levId,
    "artId" => $artId,
    "inkOrdDatum" => $inkOrdDatum,
    "inkOrdBestAantal" => $inkOrdBestAantal,
    "inkOrdStatus" => $inkOrdStatus,
]);

echo "inkooporder succesvol geüpdatet!";

?>
</div>