<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<?php require_once "navbar.php" ?>


<div class="container">
<table class="table table-dark table-hover">
            <tr>
                <th>levnaam</th>
                <th>levcontact</th>
                <th>levEmail</th>
                <th>levAdres</th>
                <th>levPostcode</th>
                <th>levWoonplaats</th>
            </tr>
<?php
require_once "gar-connect.php";

require_once "leveranciers-class.php";

// Step 1: Create a SQL query to retrieve all the data from the "leveranciers" table
$sql = "SELECT * FROM leveranciers";

// Step 2: Prepare the SQL query using PDO
$stmt = $conn->prepare($sql);

// Step 3: Execute the SQL query
$stmt->execute();

// Step 4: Fetch the results and create Article objects for each row in the "leveranciers" table
$leveranciers = array();
while ($row = $stmt->fetch()) {
    $leverancier = new Leverancier($row["levid"], $row["levnaam"], $row["levcontact"], $row["levEmail"], $row["levAdres"], $row["levPostcode"], $row["levWoonplaats"]);
    array_push($leveranciers, $leverancier);
}

// Step 5: Display the data in HTML table format


foreach ($leveranciers as $leverancier) {
    echo "<tr>";
    echo "<td>" . $leverancier->getlevnaam() . "</td>";
    echo "<td>" . $leverancier->getlevcontact() . "</td>";
    echo "<td>" . $leverancier->getlevEmail() . "</td>";
    echo "<td>" . $leverancier->getlevAdres() . "</td>";
    echo "<td>" . $leverancier->getlevPostcode() . "</td>";
    echo "<td>" . $leverancier->getlevWoonplaats() . "</td>";
    echo "</tr>";
}

echo "</table>";

?>

</body>
</html>