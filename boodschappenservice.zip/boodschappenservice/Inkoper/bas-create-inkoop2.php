<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create inkooporder</title>
</head>
<?php require_once "navbar.php";?>

<body>
    <div class="uitgevoerd">
        <?php
        require_once "inkooporders-class.php";
        function addInkooporder()
        {
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $nieuwe_inkooporder = new inkooporder(NULL, $_POST['levId'], $_POST['artId'], $_POST['inkOrdDatum'], $_POST['inkOrdBestAantal'], $_POST['inkOrdStatus']);
                // Maak een SQL-query aan om de nieuwe inkooporder toe te voegen
                $levId = $nieuwe_inkooporder->getlevId();
                $artId = $nieuwe_inkooporder->getartId();
                $inkOrdDatum = $nieuwe_inkooporder->getinkOrdDatum();
                $inkOrdBestAantal = $nieuwe_inkooporder->getinkOrdBestAantal();
                $inkOrdStatus = $nieuwe_inkooporder->getinkOrdStatus();

                require_once "gar-connect.php";

                $stmt = $conn->prepare("INSERT INTO inkooporders (levId, artId, inkOrdDatum, inkOrdBestAantal, inkOrdStatus) VALUES (:levId, :artId, :inkOrdDatum, :inkOrdBestAantal, :inkOrdStatus)");

                $stmt->bindParam(':levId', $levId);
                $stmt->bindParam(':artId', $artId);
                $stmt->bindParam(':inkOrdDatum', $inkOrdDatum);
                $stmt->bindParam(':inkOrdBestAantal', $inkOrdBestAantal);
                $stmt->bindParam(':inkOrdStatus', $inkOrdStatus);

                // Voer de query uit en check het resultaat
                if ($stmt->execute()) {
                    echo "<h2>Inkooporder toegevoegd!</h2>";
                } else {
                    echo "<p>Er is iets misgegaan. De inkooporder is niet toegevoegd.</p>";
                }
                echo "<h1>". "<a class='terug' href='navbar.php'>Terug naar het menu. </a> . </h2>";
            }
        }

        addInkooporder();

        ?>
    </div>

</body>

</html>