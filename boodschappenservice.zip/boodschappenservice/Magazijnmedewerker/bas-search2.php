<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>


<?php require_once "navbar.php" ?>
<div class="container">
<?php
require_once "gar-connect.php";
require_once "artikel-class.php";
// Verbinding maken met de database (vervang de waarden met die van jouw database)


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $artId = $_POST["artId"];

    // Zoek het artikel in de database
    $stmt = $conn->prepare("SELECT * FROM Artikelen WHERE artId = :artId");
    $stmt->bindParam(":artId", $artId);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Toon de eigenschappen van het artikel als het gevonden is
    if ($result) {
        $artikel = new Artikel($result["artId"], $result["artOmschrijving"], $result["artInkoop"], $result["artVerkoop"], $result["artVoorraad"], $result["artMinVoorraad"], $result["artMaxVoorraad"], $result["artLocatie"], $result["levId"]);
        echo "<table class='table table-dark table-hover'>";
        echo "<tr>";
        echo "<td>" ."ID: " . $artikel->artId . "<br>" . "</td>";
        echo "<td>" ."Omschrijving: " . $artikel->artOmschrijving ."</td>". "<br>";
        echo "<td>" ."Inkoop: " . $artikel->artInkoop ."</td>". "<br>";
        echo "<td>" ."Verkoop: " . $artikel->artVerkoop ."</td>". "<br>";
        echo "<td>" ."Voorraad: " . $artikel->artVoorraad ."</td>". "<br>";
        echo "<td>" ."Minimale voorraad: " . $artikel->artMinVoorraad ."</td>". "<br>";
        echo "<td>" ."Maximale voorraad: " . $artikel->artMaxVoorraad ."</td>". "<br>";
        echo "<td>" ."Locatie: " . $artikel->artLocatie ."</td>". "<br>";
        echo "<td>" ."Leverancier ID: " . $artikel->levId ."</td>". "<br>";
        echo "</tr>";
        echo "</table>";
    } else {
        echo "Artikel niet gevonden";
    }

}


$conn = null;
?>
</div>
</body>
</html>