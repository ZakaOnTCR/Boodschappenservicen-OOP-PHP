<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../main.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>
    <?php require_once "navbar.php" ?>

    <div class="container">
        <?php
        require_once "gar-connect.php";
        require_once "artikel-class.php";
        require_once "verkooporders-class.php";

        // Step 1: Create a SQL query to retrieve data from the "artikelen" and "leveranciers" tables using INNER JOIN
        $sql = "SELECT artikelen.artId, artikelen.artOmschrijving, artikelen.artInkoop, artikelen.artVerkoop, artikelen.artVoorraad, artikelen.artMinVoorraad, artikelen.artMaxVoorraad, artikelen.artLocatie, leveranciers.levAdres, leveranciers.levcontact
FROM artikelen
INNER JOIN leveranciers ON artikelen.levId = leveranciers.levId";

        // Step 2: Prepare the SQL query using PDO
        $stmt = $conn->prepare($sql);

        // Step 3: Execute the SQL query
        $stmt->execute();

        // Step 4: Fetch the results and create a new object that includes the columns from both tables
        $artikelen = array();
        while ($row = $stmt->fetch()) {
            $artikel = new stdClass();
            $artikel->artId = $row["artId"];
            $artikel->artOmschrijving = $row["artOmschrijving"];
            $artikel->artInkoop = $row["artInkoop"];
            $artikel->artVerkoop = $row["artVerkoop"];
            $artikel->artVoorraad = $row["artVoorraad"];
            $artikel->artMinVoorraad = $row["artMinVoorraad"];
            $artikel->artMaxVoorraad = $row["artMaxVoorraad"];
            $artikel->artLocatie = $row["artLocatie"];
            $artikel->levAdres = $row["levAdres"];
            $artikel->levcontact = $row["levcontact"];
            array_push($artikelen, $artikel);
        }

        // Step 5: Display the data in HTML table format
        echo "<table class='table table-dark table-hover'>
            <tr>
                <th>artOmschrijving</th>
                <th>artInkoop</th>
                <th>artVerkoop</th>
                <th>artVoorraad</th>
                <th>artMinVoorraad</th>
                <th>artMaxVoorraad</th>
                <th>artLocatie</th>
                <th>levAdres</th>
                <th>levcontact</th>
            </tr>";

        foreach ($artikelen as $artikel) {
            echo "<tr>";
            echo "<td>" . $artikel->artOmschrijving . "</td>";
            echo "<td>" . $artikel->artInkoop . "</td>";
            echo "<td>" . $artikel->artVerkoop . "</td>";
            echo "<td>" . $artikel->artVoorraad . "</td>";
            echo "<td>" . $artikel->artMinVoorraad . "</td>";
            echo "<td>" . $artikel->artMaxVoorraad . "</td>";
            echo "<td>" . $artikel->artLocatie . "</td>";
            echo "<td>" . $artikel->levcontact . "</td>";
            echo "<td>" . $artikel->levcontact . "</td>";

            echo "</tr>";


        }
        echo "</table>";