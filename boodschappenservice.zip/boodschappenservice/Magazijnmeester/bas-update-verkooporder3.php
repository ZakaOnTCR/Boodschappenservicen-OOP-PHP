<?php require_once "navbar.php"; ?>
<div class="uitgevoerd">

    <?php

    require_once "gar-connect.php";
    require_once "verkooporders-class.php";



    // Haal de waarden op uit het formulier
    


    // Maak een nieuw artikel object met de nieuwe waarden
    $artikel = new Verkooporder($verkOrdId, $klantid, $artId, $verkOrdDatum, $verkOrdBestAantal, $verkOrdStatus);

    // Update het artikel in de database
    $sql = $conn->prepare("UPDATE verkooporders SET klantid =:klantid , artId =:artId , verkOrdDatum=:verkOrdDatum, verkOrdBestAantal=:verkOrdBestAantal, verkOrdStatus=:verkOrdStatus WHERE verkOrdId =:verkOrdId ");
    $sql->execute(
        [
            "verkOrdId" => $verkOrdId,
            "klantid" => $klantid,
            "artId" => $artId,
            "verkOrdDatum" => $verkOrdDatum,
            "verkOrdBestAantal" => $verkOrdBestAantal,
            "verkOrdStatus" => $verkOrdStatus,
        ]
    );

    echo "Artikel succesvol geüpdatet!";




    ?>

</div>