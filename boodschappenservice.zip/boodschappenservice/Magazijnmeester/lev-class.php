<?php
class leverecier
{
    public $levid;
    public $levnaam;
    public $levcontact;
    public $levEmail;
    public $levAdres;
    public $levPostcode;
    public $levWoonplaats;

    // Constructor to initialize the article object
    public function __construct($levid, $levnaam, $levcontact, $levEmail, $levAdres, $levPostcode, $levWoonplaats)
    {
        $this->levid = NULL;
        $this->levnaam = $levnaam;
        $this->levcontact = $levcontact;
        $this->levEmail = $levEmail;
        $this->levAdres = $levAdres;
        $this->levPostcode = $levPostcode;
        $this->levWoonplaats = $levWoonplaats;
    }

    

    // Getter methods
    public function getlevid()
    {
        return $this->levid;
    }
    public function getlevnaam()
    {
        return $this->levnaam;
    }
    public function getlevcontact()
    {
        return $this->levcontact;
    }
    public function getlevEmail()
    {
        return $this->levEmail;
    }
    public function getlevAdres()
    {
        return $this->levAdres;
    }
    public function getlevPostcode()
    {
        return $this->levPostcode;
    }
    public function getlevWoonplaats()
    {
        return $this->levWoonplaats;
    }
}