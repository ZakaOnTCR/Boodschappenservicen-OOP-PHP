<!DOCTYPE html>
<html lang="en">

<body>

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../main.css">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <title>Document</title>

    </head>

    <header>


    </header>

    <div class="top-section">
        <img class="logo" src="../logo.png" alt="">
    </div>
    <nav>
        <ul>
            <div class="icon">
                <i class="fa fa-home" aria-hidden="true"></i>
                <li><a href="#">Home pagaina</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-search" aria-hidden="true"></i>
                <li><a href="bas-search1.php">artikel zoeken</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-pencil" aria-hidden="true"></i>
                <li><a href="bas-update1.php">artikel update</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-pencil" aria-hidden="true"></i>
                <li><a href="bas-update-verkooporder1.php">verkooporders update</a></li>
            </div>

            <div class="icon">
                <i class="fa fa-pencil" aria-hidden="true"></i>
                <li><a href="bas-update1.php">artikel update</a></li>
            </div>
        </ul>
    </nav>
    <div class="welkom">

        <?php
        session_start();
        echo "<h2>" . "Welkom " . $_SESSION['gebruiker']->gebruikernaam;
        "<h2>" ?>

    </div>
    <form class="d-flex">
        <button class="btn-uit"><a href="../bas-inloggen1.php">UITLOGGEN</a></button>
    </form>


</body>

</html>